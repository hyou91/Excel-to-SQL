import sys
import pandas as pd
import re
import os
import json
from datetime import datetime
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QFileDialog, QMessageBox,
    QTextEdit, QTableWidget, QTableWidgetItem, QComboBox,
    QLineEdit, QCheckBox, QSpinBox, QGroupBox, QProgressBar,
    QTabWidget, QSplitter, QFrame, QSlider, QMenuBar, QMenu,
    QAction, QHeaderView, QStyledItemDelegate, QStyle,
    QListWidget, QListWidgetItem, QDialog, QGridLayout,
    QColorDialog, QButtonGroup, QRadioButton
)
from PyQt5.QtCore import Qt, QThread, pyqtSignal, QTimer, QSettings
from PyQt5.QtGui import QFont, QColor, QPalette, QIcon, QPixmap, QPainter

class ColorDelegate(QStyledItemDelegate):
    """
    Custom delegate for coloring rows in the table preview.
    Highlights rows with errors (red), warnings (yellow), or Arabic text (blue)
    to visually indicate data quality issues in the preview table.
    """
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.error_rows = set()
        self.warning_rows = set()
        self.arabic_rows = set()
    
    def paint(self, painter, option, index):
        if index.row() in self.error_rows:
            option.backgroundBrush = QColor(255, 200, 200)  # Light red
        elif index.row() in self.warning_rows:
            option.backgroundBrush = QColor(255, 255, 200)  # Light yellow
        elif index.row() in self.arabic_rows:
            option.backgroundBrush = QColor(200, 200, 255)  # Light blue
        
        super().paint(painter, option, index)

class SettingsDialog(QDialog):
    """
    Dialog window for user preferences and application settings.
    Allows users to select theme (light/dark), set default preview rows,
    default table name, and enable/disable auto-saving of settings.
    """
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Settings")
        self.setFixedSize(400, 300)
        
        layout = QVBoxLayout()
        
        # Theme selection
        theme_group = QGroupBox("Theme")
        theme_layout = QVBoxLayout()
        
        self.theme_group = QButtonGroup()
        self.light_theme = QRadioButton("Light Theme")
        self.dark_theme = QRadioButton("Dark Theme")
        self.theme_group.addButton(self.light_theme, 0)
        self.theme_group.addButton(self.dark_theme, 1)
        
        theme_layout.addWidget(self.light_theme)
        theme_layout.addWidget(self.dark_theme)
        theme_group.setLayout(theme_layout)
        
        # Default settings
        defaults_group = QGroupBox("Default Settings")
        defaults_layout = QGridLayout()
        
        defaults_layout.addWidget(QLabel("Default Preview Rows:"), 0, 0)
        self.default_preview_rows = QSpinBox()
        self.default_preview_rows.setRange(1, 100)
        self.default_preview_rows.setValue(10)
        defaults_layout.addWidget(self.default_preview_rows, 0, 1)
        
        defaults_layout.addWidget(QLabel("Default Table Name:"), 1, 0)
        self.default_table_name = QLineEdit()
        defaults_layout.addWidget(self.default_table_name, 1, 1)
        
        self.auto_save_settings = QCheckBox("Auto-save settings")
        defaults_layout.addWidget(self.auto_save_settings, 2, 0, 1, 2)
        
        defaults_group.setLayout(defaults_layout)
        
        # Buttons
        button_layout = QHBoxLayout()
        ok_button = QPushButton("OK")
        cancel_button = QPushButton("Cancel")
        
        ok_button.clicked.connect(self.accept)
        cancel_button.clicked.connect(self.reject)
        
        button_layout.addWidget(ok_button)
        button_layout.addWidget(cancel_button)
        
        layout.addWidget(theme_group)
        layout.addWidget(defaults_group)
        layout.addLayout(button_layout)
        
        self.setLayout(layout)
        
        # Load current settings
        self.load_settings()
    
    def load_settings(self):
        settings = QSettings('ExcelToSQL', 'Settings')
        
        theme = settings.value('theme', 'light')
        if theme == 'dark':
            self.dark_theme.setChecked(True)
        else:
            self.light_theme.setChecked(True)
        
        self.default_preview_rows.setValue(int(settings.value('default_preview_rows', 10)))
        self.default_table_name.setText(settings.value('default_table_name', 'Hyou_UPDATE_EVS_ItemAddational_DROPSHIP_QTY_Excel'))
        self.auto_save_settings.setChecked(settings.value('auto_save_settings', True, type=bool))
    
    def save_settings(self):
        settings = QSettings('ExcelToSQL', 'Settings')
        
        theme = 'dark' if self.dark_theme.isChecked() else 'light'
        settings.setValue('theme', theme)
        settings.setValue('default_preview_rows', self.default_preview_rows.value())
        settings.setValue('default_table_name', self.default_table_name.text())
        settings.setValue('auto_save_settings', self.auto_save_settings.isChecked())

class ProcessingThread(QThread):
    """
    Background thread for processing Excel data and generating SQL scripts.
    Handles row-by-row validation, skipping, and SQL statement creation.
    Emits progress, status, and completion signals for UI updates.
    """
    
    progress = pyqtSignal(int)
    finished = pyqtSignal(str, list, dict)
    error = pyqtSignal(str)
    status_update = pyqtSignal(str)
    
    def __init__(self, df, sheet_name, item_col, qty_col, output_path, table_name, skip_arabic=True):
        super().__init__()
        self.df = df
        self.sheet_name = sheet_name
        self.item_col = item_col
        self.qty_col = qty_col
        self.output_path = output_path
        self.table_name = table_name
        self.skip_arabic = skip_arabic
        
    def run(self):
        try:
            start_time = datetime.now()
            arabic_pattern = re.compile(r'[\u0600-\u06FF]')
            sql_lines = []
            total_rows = len(self.df)
            
            # Statistics tracking
            stats = {
                'total_rows': total_rows,
                'processed_rows': 0,
                'skipped_arabic': 0,
                'skipped_invalid_qty': 0,
                'skipped_empty': 0,
                'processing_time': 0
            }
            
            for index, (_, row) in enumerate(self.df.iterrows()):
                # Update progress
                progress = int((index / total_rows) * 100)
                self.progress.emit(progress)
                
                if index % 100 == 0:  # Update status every 100 rows
                    self.status_update.emit(f"Processing row {index + 1} of {total_rows}")
                
                item = str(row[self.item_col]).strip()
                
                # Check for empty items
                if not item or item.lower() in ['nan', 'none', '']:
                    stats['skipped_empty'] += 1
                    continue
                
                # Check for Arabic text
                if self.skip_arabic and arabic_pattern.search(item):
                    stats['skipped_arabic'] += 1
                    continue
                
                # Clean item name
                item = item.replace("'", "''")
                
                # Process quantity
                qty = row[self.qty_col]
                if isinstance(qty, str):
                    qty = qty.replace(",", "").replace("$", "").strip()
                    try:
                        qty = float(qty)
                    except ValueError:
                        stats['skipped_invalid_qty'] += 1
                        continue
                elif not isinstance(qty, (int, float)):
                    stats['skipped_invalid_qty'] += 1
                    continue
                
                if qty < 0:  # Skip zero or negative quantities
                    stats['skipped_invalid_qty'] += 1
                    continue

                sql = (
                    f"EXEC [dbo].[{self.table_name}] "
                    f"@ITEMNMBR = '{item}', "
                    f"@QTY = {qty:.3f}, "
                    f"@F1 = NULL, "
                    f"@F2 = NULL"
                )
                sql_lines.append(sql)
                stats['processed_rows'] += 1
            
            # Save to file
            with open(self.output_path, 'w', encoding='utf-8') as f:
                f.write(f"-- Generated on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"-- Source: {self.sheet_name}\n")
                f.write(f"-- Total statements: {len(sql_lines)}\n\n")
                
                for line in sql_lines:
                    f.write(line + '\n')
            
            # Calculate processing time
            end_time = datetime.now()
            stats['processing_time'] = (end_time - start_time).total_seconds()
            
            self.finished.emit(self.output_path, sql_lines, stats)
            
        except Exception as e:
            self.error.emit(str(e))

class ExcelToSQLApp(QWidget):
    """
    Main application window and controller for the Excel to SQL Script Generator.
    Manages all UI components, user interactions, file operations, and
    coordinates data processing and preview.
    """
    
    def __init__(self):
        """
        Initialize the main window, load settings, set up UI, menu, theme,
        drag-and-drop, and auto-save timer.
        """
        super().__init__()
        self.setWindowTitle("Excel to SQL Script Generator v3.0")
        self.setGeometry(200, 100, 1200, 800)
        self.menubar = None
        
        # Internal state
        self.df_all_sheets = {}
        self.selected_sheet_name = None
        self.file_path = ""
        self.processing_thread = None
        self.recent_files = []
        self.processing_history = []
        
        # UI state
        self.color_delegate = ColorDelegate()
        
        # Load settings
        self.load_settings()
        
        # Setup UI
        self.init_ui()
        self.setup_menu()
        self.apply_theme()
        
        # Enable drag and drop
        self.setAcceptDrops(True)
        
        # Setup timer for auto-save
        self.auto_save_timer = QTimer()
        self.auto_save_timer.timeout.connect(self.auto_save_settings)
        self.auto_save_timer.start(30000)  # Auto-save every 30 seconds
        
    def load_settings(self):
        """
        Load user settings (theme, preview rows, table name, auto-save, recent files)
        from persistent storage using QSettings.
        """
        settings = QSettings('ExcelToSQL', 'Settings')
        
        self.theme = settings.value('theme', 'light')
        self.default_preview_rows = int(settings.value('default_preview_rows', 10))
        self.default_table_name = settings.value('default_table_name', 'Hyou_UPDATE_EVS_ItemAddational_DROPSHIP_QTY_Excel')
        self.auto_save_enabled = settings.value('auto_save_settings', True, type=bool)
        
        # Load recent files
        self.recent_files = settings.value('recent_files', [], type=list)
        if len(self.recent_files) > 10:  # Keep only last 10 files
            self.recent_files = self.recent_files[-10:]
    
    def save_settings(self):
        """
        Save current user settings to persistent storage using QSettings.
        """
        settings = QSettings('ExcelToSQL', 'Settings')
        
        settings.setValue('theme', self.theme)
        settings.setValue('default_preview_rows', self.default_preview_rows)
        settings.setValue('default_table_name', self.default_table_name)
        settings.setValue('auto_save_settings', self.auto_save_enabled)
        settings.setValue('recent_files', self.recent_files)
    
    def auto_save_settings(self):
        """
        Automatically save settings if auto-save is enabled.
        Triggered by a timer every 30 seconds.
        """
        if self.auto_save_enabled:
            self.save_settings()
    
    def setup_menu(self):
        """
        Set up the application menu bar, including File, Settings, and Help menus.
        Adds actions for opening files, managing recent files, preferences, and about dialog.
        """
        self.menubar = QMenuBar(self)
        
        # File menu
        file_menu = self.menubar.addMenu('File')
        
        open_action = QAction('Open Excel File', self)
        open_action.setShortcut('Ctrl+O')
        open_action.triggered.connect(self.process_excel)
        file_menu.addAction(open_action)
        
        file_menu.addSeparator()
        
        # Recent files submenu
        self.recent_menu = file_menu.addMenu('Recent Files')
        self.update_recent_menu()
        
        file_menu.addSeparator()
        
        exit_action = QAction('Exit', self)
        exit_action.setShortcut('Ctrl+Q')
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # Settings menu
        settings_menu = self.menubar.addMenu('Settings')
        
        preferences_action = QAction('Preferences', self)
        preferences_action.triggered.connect(self.show_settings)
        settings_menu.addAction(preferences_action)
        
        # Help menu
        help_menu = self.menubar.addMenu('Help')
        
        about_action = QAction('About', self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)
    
    def update_recent_menu(self):
        """
        Refresh the 'Recent Files' submenu with the latest file paths.
        Only includes files that still exist on disk.
        """
        self.recent_menu.clear()
        
        for file_path in self.recent_files:
            if os.path.exists(file_path):
                action = QAction(os.path.basename(file_path), self)
                action.setData(file_path)
                action.triggered.connect(lambda checked, path=file_path: self.load_recent_file(path))
                self.recent_menu.addAction(action)
        
        if not self.recent_files:
            no_recent_action = QAction('No recent files', self)
            no_recent_action.setEnabled(False)
            self.recent_menu.addAction(no_recent_action)
    
    def load_recent_file(self, file_path):
        """
        Load an Excel file from the recent files list and trigger the loading process.
        """
        self.file_path = file_path
        self.load_excel_file()
    
    def show_settings(self):
        """
        Open the settings/preferences dialog for user customization.
        Applies changes if the dialog is accepted.
        """
        dialog = SettingsDialog(self)
        if dialog.exec_() == QDialog.Accepted:
            dialog.save_settings()
            self.load_settings()
            self.apply_theme()
    
    def show_about(self):
        """
        Display an 'About' dialog with application version and description.
        """
        QMessageBox.about(self, "About", 
            "Excel to SQL Script Generator v3.0\n\n"
            "A powerful tool for converting Excel data to SQL scripts\n"
            "with advanced features and customization options.")
    
    def apply_theme(self):
        """
        Apply the selected theme (light or dark) to the entire UI using Qt style sheets.
        """
        if self.theme == 'dark':
            self.setStyleSheet("""
                QWidget {
                    background-color: #2b2b2b;
                    color: #ffffff;
                }
                QGroupBox {
                    font-weight: bold;
                    border: 2px solid #555555;
                    border-radius: 8px;
                    margin-top: 10px;
                    padding-top: 10px;
                }
                QGroupBox::title {
                    subcontrol-origin: margin;
                    left: 10px;
                    padding: 0 5px 0 5px;
                }
                QPushButton {
                    background-color: #404040;
                    border: 1px solid #555555;
                    border-radius: 4px;
                    padding: 8px;
                    min-width: 80px;
                }
                QPushButton:hover {
                    background-color: #505050;
                }
                QPushButton:pressed {
                    background-color: #606060;
                }
                QLineEdit, QComboBox, QSpinBox {
                    background-color: #404040;
                    border: 1px solid #555555;
                    border-radius: 4px;
                    padding: 4px;
                }
                QTableWidget {
                    background-color: #353535;
                    alternate-background-color: #404040;
                    gridline-color: #555555;
                }
                QTextEdit {
                    background-color: #353535;
                    border: 1px solid #555555;
                }
                QProgressBar {
                    background-color: #404040;
                    border: 1px solid #555555;
                    border-radius: 4px;
                    text-align: center;
                }
                QProgressBar::chunk {
                    background-color: #4a9eff;
                    border-radius: 3px;
                }
                QTabWidget::pane {
                    border: 2px solid #555555;
                    border-radius: 8px;
                    background: #353535;
                }
                QTabBar::tab {
                    background: #404040;
                    color: #ffffff;
                    border: 1px solid #555555;
                    border-radius: 4px;
                    padding: 8px;
                    min-width: 100px;
                }
                QTabBar::tab:selected {
                    background: #4a9eff;
                    color: #ffffff;
                }
            """)
        else:
            self.setStyleSheet("""
                QGroupBox {
                    font-weight: bold;
                    border: 2px solid #cccccc;
                    border-radius: 8px;
                    margin-top: 10px;
                    padding-top: 10px;
                }
                QGroupBox::title {
                    subcontrol-origin: margin;
                    left: 10px;
                    padding: 0 5px 0 5px;
                }
                QPushButton {
                    background-color: #f0f0f0;
                    border: 1px solid #cccccc;
                    border-radius: 4px;
                    padding: 8px;
                    min-width: 80px;
                }
                QPushButton:hover {
                    background-color: #e0e0e0;
                }
                QPushButton:pressed {
                    background-color: #d0d0d0;
                }
                QProgressBar {
                    background-color: #f0f0f0;
                    border: 1px solid #cccccc;
                    border-radius: 4px;
                    text-align: center;
                }
                QProgressBar::chunk {
                    background-color: #4a9eff;
                    border-radius: 3px;
                }
                QTabWidget::pane {
                    
                    border: 2px solid #cccccc;
                    border-radius: 8px;
                    background: #f0f0f0;
                }
                QTabBar::tab {
                    background: #f0f0f0;
                    color: #000000;
                    border: 1px solid #cccccc;
                    border-radius: 4px;
                    padding: 8px;
                    min-width: 100px;
                }
                QTabBar::tab:selected {
                    background: #4a9eff;
                    color: #ffffff;
                }
            """)
    
    def dragEnterEvent(self, event):
        """
        Enable drag-and-drop for Excel files by accepting drag events with file URLs.
        """
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
    
    def dropEvent(self, event):
        """
        Handle dropped Excel files, set the file path, and trigger loading.
        """
        for url in event.mimeData().urls():
            file_path = url.toLocalFile()
            if file_path.endswith(('.xlsx', '.xls')):
                self.file_path = file_path
                self.load_excel_file()
                break
    
    def init_ui(self):
        """
        Build and arrange all UI components: file selection, column mapping,
        configuration, processing controls, preview, statistics, log, and history tabs.
        """
        main_layout = QVBoxLayout()
        
        # Add menu bar
        main_layout.setMenuBar(self.menubar)
        
        # Create main splitter
        main_splitter = QSplitter(Qt.Horizontal)
        
        # Left panel
        left_panel = QWidget()
        left_layout = QVBoxLayout()
        
        # File selection section
        file_group = QGroupBox("📁 File Selection")
        file_layout = QVBoxLayout()
        
        # Drop zone
        self.drop_zone = QLabel("📂 Drop Excel file here or click to browse")
        self.drop_zone.setAlignment(Qt.AlignCenter)
        self.drop_zone.setStyleSheet("""
            QLabel {
                border: 2px dashed #cccccc;
                border-radius: 8px;
                padding: 20px;
                font-size: 14px;
                color: #666666;
            }
        """)
        self.drop_zone.setMinimumHeight(80)
        self.drop_zone.mousePressEvent = lambda e: self.process_excel()
        
        self.file_label = QLabel("No file selected")
        self.file_button = QPushButton("Browse Files")
        self.file_button.clicked.connect(self.process_excel)
        
        # Sheet selection
        sheet_layout = QHBoxLayout()
        self.sheet_label = QLabel("Sheet:")
        self.sheet_label.hide()
        self.sheet_selector = QComboBox()
        self.sheet_selector.hide()
        self.sheet_selector.currentIndexChanged.connect(self.on_sheet_changed)
        sheet_layout.addWidget(self.sheet_label)
        sheet_layout.addWidget(self.sheet_selector)
        
        file_layout.addWidget(self.drop_zone)
        file_layout.addWidget(self.file_label)
        file_layout.addWidget(self.file_button)
        file_layout.addLayout(sheet_layout)
        file_group.setLayout(file_layout)
        
        # Column mapping section
        mapping_group = QGroupBox("🔗 Column Mapping")
        mapping_layout = QGridLayout()
        
        mapping_layout.addWidget(QLabel("Item Column:"), 0, 0)
        self.item_column_combo = QComboBox()
        mapping_layout.addWidget(self.item_column_combo, 0, 1)
        
        mapping_layout.addWidget(QLabel("Quantity Column:"), 1, 0)
        self.qty_column_combo = QComboBox()
        mapping_layout.addWidget(self.qty_column_combo, 1, 1)
        
        mapping_group.setLayout(mapping_layout)
        
        # Configuration section
        config_group = QGroupBox("⚙️ Configuration")
        config_layout = QVBoxLayout()
        
        # Output file settings
        output_layout = QHBoxLayout()
        output_layout.addWidget(QLabel("Output file:"))
        self.output_path_input = QLineEdit("output_script.sql")
        self.browse_output_button = QPushButton("Browse")
        self.browse_output_button.clicked.connect(self.browse_output_file)
        output_layout.addWidget(self.output_path_input)
        output_layout.addWidget(self.browse_output_button)
        
        # Table name setting
        table_layout = QHBoxLayout()
        table_layout.addWidget(QLabel("Stored Procedure:"))
        self.table_name_input = QLineEdit(self.default_table_name)
        table_layout.addWidget(self.table_name_input)
        
        # Options
        self.skip_arabic_check = QCheckBox("Skip rows with Arabic text")
        self.skip_arabic_check.setChecked(True)
        
        self.validate_data_check = QCheckBox("Validate data quality")
        self.validate_data_check.setChecked(True)
        
        config_layout.addLayout(output_layout)
        config_layout.addLayout(table_layout)
        config_layout.addWidget(self.skip_arabic_check)
        config_layout.addWidget(self.validate_data_check)
        config_group.setLayout(config_layout)
        
        # Processing section
        process_group = QGroupBox("🚀 Processing")
        process_layout = QVBoxLayout()
        
        self.generate_button = QPushButton("Generate SQL Script")
        self.generate_button.clicked.connect(self.generate_sql)
        self.generate_button.setEnabled(False)
        
        self.progress_bar = QProgressBar()
        self.progress_bar.hide()
        
        self.status_label = QLabel("")
        self.status_label.hide()
        
        process_layout.addWidget(self.generate_button)
        process_layout.addWidget(self.progress_bar)
        process_layout.addWidget(self.status_label)
        process_group.setLayout(process_layout)
        
        # Add all groups to left panel
        left_layout.addWidget(file_group)
        left_layout.addWidget(mapping_group)
        left_layout.addWidget(config_group)
        left_layout.addWidget(process_group)
        left_layout.addStretch()
        left_panel.setLayout(left_layout)
        
        # Right panel with tabs
        right_panel = QTabWidget()
        
        # Preview tab
        preview_tab = QWidget()
        preview_layout = QVBoxLayout()
        
        preview_controls = QHBoxLayout()
        preview_controls.addWidget(QLabel("Preview rows:"))
        self.preview_rows_spin = QSpinBox()
        self.preview_rows_spin.setRange(1, 100)
        self.preview_rows_spin.setValue(self.default_preview_rows)
        self.preview_rows_spin.valueChanged.connect(self.update_preview)
        preview_controls.addWidget(self.preview_rows_spin)
        preview_controls.addStretch()
        
        self.table_output = QTableWidget()
        self.table_output.setItemDelegate(self.color_delegate)
        self.table_output.setAlternatingRowColors(True)
        
        preview_layout.addLayout(preview_controls)
        preview_layout.addWidget(self.table_output)
        preview_tab.setLayout(preview_layout)
        
        # Statistics tab
        stats_tab = QWidget()
        stats_layout = QVBoxLayout()
        
        self.stats_text = QTextEdit()
        self.stats_text.setReadOnly(True)
        stats_layout.addWidget(self.stats_text)
        stats_tab.setLayout(stats_layout)
        
        # Log tab
        log_tab = QWidget()
        log_layout = QVBoxLayout()
        
        self.text_output = QTextEdit()
        self.text_output.setReadOnly(True)
        log_layout.addWidget(self.text_output)
        log_tab.setLayout(log_layout)
        
        # History tab
        history_tab = QWidget()
        history_layout = QVBoxLayout()
        
        self.history_list = QListWidget()
        history_layout.addWidget(self.history_list)
        history_tab.setLayout(history_layout)
        
        # Add tabs
        right_panel.addTab(preview_tab, "📊 Preview")
        right_panel.addTab(stats_tab, "📈 Statistics")
        right_panel.addTab(log_tab, "📝 Log")
        right_panel.addTab(history_tab, "🕐 History")
        
        # Add panels to splitter
        main_splitter.addWidget(left_panel)
        main_splitter.addWidget(right_panel)
        main_splitter.setSizes([400, 800])
        
        main_layout.addWidget(main_splitter)
        self.setLayout(main_layout)
    
    def add_to_recent_files(self, file_path):
        """
        Add a file to the recent files list, ensuring no duplicates and a max of 10 entries.
        """
        if file_path in self.recent_files:
            self.recent_files.remove(file_path)
        self.recent_files.append(file_path)
        if len(self.recent_files) > 10:
            self.recent_files.pop(0)
        self.update_recent_menu()
    
    def browse_output_file(self):
        """
        Open a file dialog for the user to select where to save the generated SQL script.
        """
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Save SQL Script", "", "SQL Files (*.sql);;All Files (*)"
        )
        if file_path:
            self.output_path_input.setText(file_path)
    
    def process_excel(self):
        """
        Handle Excel file selection, either from drag-and-drop or file dialog,
        and trigger loading of the selected file.
        """
        if not self.file_path:
            self.file_path, _ = QFileDialog.getOpenFileName(
                self, "Select Excel File", "", "Excel Files (*.xlsx *.xls)"
            )
        
        if self.file_path:
            self.load_excel_file()
    
    def load_excel_file(self):
        """
        Load the selected Excel file, read all sheets, update the UI,
        and prepare for data preview and processing.
        """
        try:
            self.add_to_recent_files(self.file_path)
            
            # Load all sheets
            self.df_all_sheets = pd.read_excel(self.file_path, sheet_name=None)
            sheet_names = list(self.df_all_sheets.keys())

            self.file_label.setText(f"✔ File loaded: {os.path.basename(self.file_path)}")
            self.drop_zone.setText(f"✔ {os.path.basename(self.file_path)} loaded")
            self.text_output.clear()
            
            # Debug info
            debug_info = f"Found {len(sheet_names)} sheet(s): {', '.join(sheet_names)}"
            self.text_output.append(debug_info)

            # Setup sheet selector
            self.sheet_selector.clear()
            self.sheet_selector.addItems(sheet_names)
            self.sheet_selector.setCurrentIndex(0)
            
            # Show sheet selector
            self.sheet_selector.show()
            self.sheet_label.show()
            
            if len(sheet_names) > 1:
                self.text_output.append("Multiple sheets found - please select one from the dropdown.")
            else:
                self.text_output.append("Single sheet found - automatically selected.")
            
            self.selected_sheet_name = self.sheet_selector.currentText()
            self.reload_sheet_data()
                
            self.generate_button.setEnabled(True)
            self.file_path = ""  # Reset for next file

        except Exception as e:
            self.file_label.setText("Error loading Excel file.")
            self.drop_zone.setText("📂 Drop Excel file here or click to browse")
            self.text_output.append(f"Error: {str(e)}")
            QMessageBox.critical(self, "Error", str(e))
            self.generate_button.setEnabled(False)

    def on_sheet_changed(self):
        """
        Respond to user changing the selected sheet in the combo box.
        Updates the preview and statistics for the new sheet.
        """
        self.selected_sheet_name = self.sheet_selector.currentText()
        self.reload_sheet_data()
    
    def update_preview(self):
        """
        Update the data preview table and statistics panel based on the current
        sheet and preview row count. Validates data if enabled.
        """
        # Fix: Only reload if a sheet is selected and exists in loaded sheets
        if self.selected_sheet_name and self.selected_sheet_name in self.df_all_sheets:
            self.reload_sheet_data()
        else:
            self.file_label.setText("No sheet selected or sheet not found.")
            self.table_output.clear()
            self.stats_text.clear()

    def reload_sheet_data(self):
        """
        Reload data for the currently selected sheet, update column mapping combos,
        and refresh the preview and statistics.
        """
        try:
            sheet_name = self.selected_sheet_name
            # Fix: Check if sheet_name exists in loaded sheets
            if not sheet_name or sheet_name not in self.df_all_sheets:
                self.file_label.setText("Sheet not found.")
                self.table_output.clear()
                self.stats_text.clear()
                return
            df = self.df_all_sheets[sheet_name]
            
            # Update column mapping combos
            self.item_column_combo.clear()
            self.qty_column_combo.clear()
            
            column_names = [str(col) for col in df.columns]
            self.item_column_combo.addItems(column_names)
            self.qty_column_combo.addItems(column_names)
            
            # Set defaults
            if len(column_names) >= 2:
                self.qty_column_combo.setCurrentIndex(1)
            
            self.display_preview(df, sheet_name)
        except Exception as e:
            self.file_label.setText("Error reading sheet.")
            self.table_output.clear()
            self.stats_text.clear()
            QMessageBox.critical(self, "Sheet Error", str(e))

    def display_preview(self, df, sheet_name):
        """
        Show a preview of the data in the table widget, applying color highlights
        for validation issues and updating statistics.
        """
        arabic_pattern = re.compile(r'[\u0600-\u06FF]')
        preview_rows = self.preview_rows_spin.value()
        df_preview = df.head(preview_rows)
        
        # Reset delegate row sets
        self.color_delegate.error_rows.clear()
        self.color_delegate.warning_rows.clear()
        self.color_delegate.arabic_rows.clear()
        
        # Validate data if enabled
        if self.validate_data_check.isChecked():
            self.validate_preview_data(df_preview, arabic_pattern)
        
        self.display_dataframe(df_preview)
        self.update_statistics(df, sheet_name)

    def validate_preview_data(self, df_preview, arabic_pattern):
        """
        Validate the preview data for empty items, Arabic text, and invalid quantities.
        Marks rows for coloring in the preview table.
        """
        item_col_idx = self.item_column_combo.currentIndex()
        qty_col_idx = self.qty_column_combo.currentIndex()
        
        if item_col_idx == -1 or qty_col_idx == -1:
            return
        
        for row_idx, (_, row) in enumerate(df_preview.iterrows()):
            has_issues = False
            
            # Check item column
            if item_col_idx < len(row):
                item = str(row.iloc[item_col_idx]).strip()
                if arabic_pattern.search(item):
                    self.color_delegate.arabic_rows.add(row_idx)
                    has_issues = True
                elif not item or item.lower() in ['nan', 'none', '']:
                    self.color_delegate.error_rows.add(row_idx)
                    has_issues = True
            
            # Check quantity column
            if qty_col_idx < len(row):
                qty = row.iloc[qty_col_idx]
                if isinstance(qty, str):
                    qty_clean = qty.replace(",", "").replace("$", "").strip()
                    try:
                        qty_val = float(qty_clean)
                        if qty_val <= 0:
                            self.color_delegate.warning_rows.add(row_idx)
                    except ValueError:
                        self.color_delegate.error_rows.add(row_idx)
                        has_issues = True
                elif not isinstance(qty, (int, float)) or qty <= 0:
                    if not has_issues:  # Don't override error with warning
                        self.color_delegate.warning_rows.add(row_idx)

    def update_statistics(self, df, sheet_name):
        """
        Calculate and display statistics about the current sheet's data,
        including valid/invalid rows, empty items, Arabic text, and more.
        """
        arabic_pattern = re.compile(r'[\u0600-\u06FF]')
        item_col_idx = self.item_column_combo.currentIndex()
        qty_col_idx = self.qty_column_combo.currentIndex()
        
        if item_col_idx == -1 or qty_col_idx == -1:
            return
        
        item_col = df.columns[item_col_idx]
        qty_col = df.columns[qty_col_idx]
        
        # Calculate statistics
        total_rows = len(df)
        valid_rows = 0
        arabic_rows = 0
        empty_rows = 0
        invalid_qty_rows = 0
        
        for _, row in df.iterrows():
            item = str(row[item_col]).strip()
            qty = row[qty_col]
            
            # Check item
            if not item or item.lower() in ['nan', 'none', '']:
                empty_rows += 1
                continue
            
            if arabic_pattern.search(item):
                arabic_rows += 1
                continue
            
            # Check quantity
            if isinstance(qty, str):
                qty_clean = qty.replace(",", "").replace("$", "").strip()
                try:
                    qty_val = float(qty_clean)
                    if qty_val > 0:
                        valid_rows += 1
                    else:
                        invalid_qty_rows += 1
                except ValueError:
                    invalid_qty_rows += 1
            elif isinstance(qty, (int, float)) and qty > 0:
                valid_rows += 1
            else:
                invalid_qty_rows += 1
        
        # Update statistics display
        stats_text = f"""
📊 DATA STATISTICS

📄 Sheet: {sheet_name}
📋 Total Rows: {total_rows:,}
✅ Valid Rows: {valid_rows:,} ({valid_rows/total_rows*100:.1f}%)
❌ Invalid Rows: {total_rows - valid_rows:,} ({(total_rows - valid_rows)/total_rows*100:.1f}%)

📊 BREAKDOWN:
• Empty Items: {empty_rows:,}
• Arabic Text: {arabic_rows:,}
• Invalid Quantities: {invalid_qty_rows:,}

🔍 COLUMNS:
• Item Column: {item_col}
• Quantity Column: {qty_col}

🎨 COLOR CODING:
• 🔴 Red: Critical errors (empty items, invalid quantities)
• 🟡 Yellow: Warnings (zero/negative quantities)
• 🔵 Blue: Arabic text (will be skipped if option enabled)
"""
        
        self.stats_text.setText(stats_text)
        
        # Update log
        report = [
            f"📄 Sheet: {sheet_name}",
            f"📊 Total Rows: {total_rows:,}, Valid: {valid_rows:,}",
            f"🔍 Using columns: '{item_col}' (item), '{qty_col}' (quantity)",
            f"📋 Preview showing first {min(self.preview_rows_spin.value(), total_rows)} rows"
        ]
        
        self.text_output.setText("\n".join(report))

    def generate_sql(self):
        """
        Start the SQL script generation process in a background thread.
        Validates user selections and updates UI for progress.
        """
        if not self.selected_sheet_name:
            QMessageBox.warning(self, "Warning", "Please select a sheet first.")
            return
            
        df = self.df_all_sheets[self.selected_sheet_name]
        
        item_col_idx = self.item_column_combo.currentIndex()
        qty_col_idx = self.qty_column_combo.currentIndex()
        
        if item_col_idx == -1 or qty_col_idx == -1:
            QMessageBox.critical(self, "Error", "Please select both item and quantity columns.")
            return
        
        item_col = df.columns[item_col_idx]
        qty_col = df.columns[qty_col_idx]
        output_path = self.output_path_input.text()
        table_name = self.table_name_input.text()
        skip_arabic = self.skip_arabic_check.isChecked()
        
        if not output_path:
            QMessageBox.warning(self, "Warning", "Please specify an output file path.")
            return
        
        # Show progress bar and status
        self.progress_bar.show()
        self.progress_bar.setValue(0)
        self.status_label.show()
        self.status_label.setText("Starting processing...")
        self.generate_button.setEnabled(False)
        
        # Start processing in separate thread
        self.processing_thread = ProcessingThread(
            df, self.selected_sheet_name, item_col, qty_col, 
            output_path, table_name, skip_arabic
        )
        self.processing_thread.progress.connect(self.update_progress)
        self.processing_thread.status_update.connect(self.update_status)
        self.processing_thread.finished.connect(self.on_processing_finished)
        self.processing_thread.error.connect(self.on_processing_error)
        self.processing_thread.start()
    
    def update_progress(self, value):
        """
        Update the progress bar during SQL script generation.
        """
        self.progress_bar.setValue(value)
    
    def update_status(self, message):
        """
        Update the status label with a message during processing.
        """
        self.status_label.setText(message)
    
    def on_processing_finished(self, output_path, sql_lines, stats):
        """
        Handle completion of SQL script generation: update history, show report,
        and display a success message.
        """
        self.progress_bar.hide()
        self.status_label.hide()
        self.generate_button.setEnabled(True)
        
        # Add to processing history
        history_entry = {
            'timestamp': datetime.now().isoformat(),
            'file': os.path.basename(output_path),
            'sheet': self.selected_sheet_name,
            'stats': stats
        }
        self.processing_history.append(history_entry)
        self.update_history_display()
        
        # Create detailed report
        report = [
            f"✅ SQL script generated successfully!",
            f"📁 Output file: {output_path}",
            f"⏱️ Processing time: {stats['processing_time']:.2f} seconds",
            f"📊 Total rows processed: {stats['total_rows']:,}",
            f"✅ Valid SQL statements: {stats['processed_rows']:,}",
            f"⚠️ Rows skipped:",
            f"  • Arabic text: {stats['skipped_arabic']:,}",
            f"  • Invalid quantities: {stats['skipped_invalid_qty']:,}",
            f"  • Empty items: {stats['skipped_empty']:,}",
            f"💾 File size: {os.path.getsize(output_path):,} bytes"
        ]
        
        self.text_output.append("\n" + "\n".join(report))
        
        # Show success message
        success_msg = (
            f"SQL script created successfully!\n\n"
            f"Generated {stats['processed_rows']:,} SQL statements\n"
            f"Processing time: {stats['processing_time']:.2f} seconds\n\n"
            f"Saved to: {output_path}"
        )
        QMessageBox.information(self, "Success", success_msg)
    
    def on_processing_error(self, error_msg):
        """
        Handle errors that occur during SQL script generation and notify the user.
        """
        self.progress_bar.hide()
        self.status_label.hide()
        self.generate_button.setEnabled(True)
        self.text_output.append(f"\n❌ Error: {error_msg}")
        QMessageBox.critical(self, "Processing Error", error_msg)

    def update_history_display(self):
        """
        Refresh the processing history tab with details of past script generations.
        """
        self.history_list.clear()
        
        for entry in reversed(self.processing_history):  # Show most recent first
            timestamp = datetime.fromisoformat(entry['timestamp'])
            time_str = timestamp.strftime('%Y-%m-%d %H:%M:%S')
            stats = entry['stats']
            
            item_text = (
                f"🕐 {time_str}\n"
                f"📁 {entry['file']} (Sheet: {entry['sheet']})\n"
                f"📊 {stats['processed_rows']:,} statements generated "
                f"({stats['processing_time']:.1f}s)"
            )
            
            item = QListWidgetItem(item_text)
            item.setData(Qt.UserRole, entry)
            self.history_list.addItem(item)

    def display_dataframe(self, df):
        """
        Display a pandas DataFrame in the table widget, making cells read-only
        and auto-resizing columns.
        """
        self.table_output.clear()
        self.table_output.setRowCount(0)
        self.table_output.setColumnCount(0)

        if df.empty:
            return

        self.table_output.setColumnCount(len(df.columns))
        self.table_output.setRowCount(len(df.index))
        self.table_output.setHorizontalHeaderLabels([str(col) for col in df.columns])

        for row in range(len(df.index)):
            for col in range(len(df.columns)):
                value = str(df.iat[row, col])
                item = QTableWidgetItem(value)
                
                # Make cells read-only
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                
                self.table_output.setItem(row, col, item)

        # Auto-resize columns but limit maximum width
        self.table_output.resizeColumnsToContents()
        header = self.table_output.horizontalHeader()
        for i in range(self.table_output.columnCount()):
            if header.sectionSize(i) > 200:
                header.resizeSection(i, 200)

    def closeEvent(self, event):
        """
        Save settings when the application is closed.
        """
        self.save_settings()
        event.accept()

def main():
    """
    Main entry point for the application.
    Initializes the QApplication, sets up the main window, and starts the event loop.
    """
    app = QApplication(sys.argv)
    app.setApplicationName("Excel to SQL Converter")
    app.setOrganizationName("ExcelToSQL")
    
    # Set application icon (you can add an icon file)
    # app.setWindowIcon(QIcon('icon.png'))
    
    window = ExcelToSQLApp()
    window.show()
    
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()  # Run the application