# pip install pyqt5 pandas openpyxl

import sys
import pandas as pd
import re
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout,
    QPushButton, QLabel, QFileDialog,
    QMessageBox, QTextEdit, QTableWidget, QTableWidgetItem
)

class ExcelToSQLApp(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Excel to SQL Script Generator")
        self.setGeometry(300, 200, 700, 600)

        # UI Elements
        self.label = QLabel("No file selected")
        self.text_output = QTextEdit()
        self.text_output.setReadOnly(True)
        self.table_output = QTableWidget()
        self.button = QPushButton("Select Excel File")
        self.button.clicked.connect(self.process_excel)

        # Layout
        layout = QVBoxLayout()
        layout.addWidget(self.label)
        layout.addWidget(self.button)
        layout.addWidget(QLabel("📋 Preview of Excel File:"))
        layout.addWidget(self.table_output)
        layout.addWidget(QLabel("📝 Log Output:"))
        layout.addWidget(self.text_output)
        self.setLayout(layout)

    def process_excel(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Select Excel File", "", "Excel Files (*.xlsx *.xls)"
        )
        if not file_path:
            return

        try:
            # Arabic character pattern
            arabic_pattern = re.compile(r'[\u0600-\u06FF]')

            # Load Excel file
            df = pd.read_excel(file_path)
            num_rows, num_cols = df.shape
            df_preview = df.head()

            # Show preview table
            self.display_dataframe(df_preview)

            # Filtered columns: no Arabic, not 'Unnamed:'
            valid_columns = []
            for col in df.columns:
                has_arabic = bool(arabic_pattern.search(col))
                is_unnamed = col.startswith("Unnamed:")
                if not has_arabic and not is_unnamed:
                    valid_columns.append(col)

            # Logging output
            report = [
                f"✔ File loaded: {file_path}",
                f"📊 Rows: {num_rows}, Columns: {num_cols}",
                "🧾 Filtered Columns (no Arabic, not 'Unnamed:'):"
            ] + [f" - {col}" for col in valid_columns]

            # SQL Generation
            if len(df.columns) < 2:
                raise Exception("Excel must contain at least two columns.")

            item_col = df.columns[0]
            qty_col = df.columns[1]
            sql_lines = []

            for _, row in df.iterrows():
                item = str(row[item_col]).strip()
                if arabic_pattern.search(item):
                    continue
                item = item.replace("'", "''")
                qty = row[qty_col]

                if isinstance(qty, str):
                    qty = qty.replace(",", "")
                    try:
                        qty = float(qty)
                    except ValueError:
                        continue
                elif not isinstance(qty, (int, float)):
                    continue

                sql = (
                    f"EXEC [dbo].[Hyou_UPDATE_EVS_ItemAddational_DROPSHIP_QTY_Excel] "
                    f"@ITEMNMBR = '{item}', "
                    f"@QTY = {qty:.3f}, "
                    f"@F1 = NULL, "
                    f"@F2 = NULL"
                )
                sql_lines.append(sql)

            # Save SQL script
            output_path = "output_script.sql"
            with open(output_path, 'w', encoding='utf-8') as f:
                for line in sql_lines:
                    f.write(line + '\n')

            report.append(f"\n✅ SQL script saved to: {output_path}")
            self.label.setText("Processing complete.")
            self.text_output.setText("\n".join(report))
            QMessageBox.information(self, "Success", "SQL script created successfully!")

        except Exception as e:
            self.label.setText("An error occurred.")
            QMessageBox.critical(self, "Error", str(e))

    def display_dataframe(self, df):
        self.table_output.clear()
        self.table_output.setRowCount(0)
        self.table_output.setColumnCount(0)

        if df.empty:
            return

        self.table_output.setColumnCount(len(df.columns))
        self.table_output.setRowCount(len(df.index))
        self.table_output.setHorizontalHeaderLabels(df.columns.astype(str))

        for row in range(len(df.index)):
            for col in range(len(df.columns)):
                value = str(df.iat[row, col])
                self.table_output.setItem(row, col, QTableWidgetItem(value))


# Run the app
app = QApplication(sys.argv)
window = ExcelToSQLApp()
window.show()
sys.exit(app.exec_())
